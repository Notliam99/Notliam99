---
tags:
  - 7dit
  - dit
publish: "true"
title: 7DIT Major Project Portfolio
---
> [!important]  
> Student Name:  Liam Tietjens
  
> [!important]  
> Project Title:  Notes R Us
  
> [!important]  
> Project Description:  Online Blogging platform

  

[[Formal Project Proposal]]

## 🔗 Portfolio Links

---

### 🗃 Github Repo

---

  

### 💼 Github Project

---

👷‍♀️ Github Project Page

### 🏃‍♂️ Sprint Documentation

---

[[Sprint 1 - 7th June]]

[[Sprint 2 - 10th July]]

[[Sprint 3 - 22nd August]]

[[Final Project]]

## 📄 Additional Documentation (dependent on 2nd assessment)

---

[[2.3 Database - Assessment Criteria Checklist]]

  

[[2.4 Digital Media Outcome - Assessment Criteria Checklist]]

[[Efficient Tools and Techniques (2.4 Excellence Criteria)]]

  

[[2.7 Programming Re-assessment - Assessment Criteria Checklist]]

[[Testing Plan]]

  

## 📑 Reference Pages

---

[[Project Overview]]

[[Github Guide]]

[[Assessment Information]]

[[Handing in your project]]