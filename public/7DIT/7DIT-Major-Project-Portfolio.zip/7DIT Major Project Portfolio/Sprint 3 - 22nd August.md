---
tags:
  - 7dit
  - dit
  - dit-28
  - dit-23
publish: "true"
---
# Sprint Planning
We have a plan! I'm going to work on our new client authentication idea, Zac will work on the landing page and Yuri will work on Vue tour. My new idea for client authentication is to have the is based upon client tokens and doing away with user logins. Opting for a more 
> [!important]  
> At the start of each sprint, look through your backlog and decide which tasks you will aim to complete during this sprint. Add these tasks to the relevant sprint, and add labels indicating which relevant implications each task addresses  

### Project Board Screenshot (Start of sprint)
![[Pasted image 20240726171649.png]]
### Commentary (including brief outline of how relevant implications will be addressed)
I will address the relevant implications by making our API open so that other people can view how the application works. this addresses the relevant implication Privacy but allowing users to see what data exactly is shared. I will also address the relevant implication functionality. I will achieve this by implementing the database in our application. Allowing proper sharing of notes throw our app. 

# Development Log
> [!important]  
> As you work on your project, take note of key trialling and testing in this section  
### 2024-07-26 Database Integration Begin
- cargo.toml cleanup and addition of SeaOrm ![[Pasted image 20240726171901.png]]

### 2024-07-26 Database Schema
I have Re-designed the database schema around a new idea. we have decided to completely drop Hanko authentication and any conventional authentication flow. We have pivoted to an idea of User accounts being bonded to client sessions. These client sessions are in control of future sign ins using two factor codes. This simplify the user experience and removes liability of saving sensitive info like passwords and emails. https://dbdocs.io/21ltietjens/Notes-R-Us 
### 2024-08-02 Completed SeaOrm Database Migrations
I have implemented migrations for the database schema witch basically is a script that initialises the database. The migrations were completed in this commit: [HERE](https://github.com/l2dit/NotesRUs/commit/fd35e13238dfafee4e65318c5fc513276f8a9492). I ran into one issue with this being that SQLite is weird, SQLite doesn't mind if you make a foreign key reference to a table that does not exist. This makes you have to define these at once PostgreSQL rather dose not like this so i had to check what database was used and change accordingly.
### 2024-08-04 Starting Writing Of SeaOrm Entity
I just generated this code using the SeaOrm command line.

### 2024-08-06 SeaOrm Entity Done
It Works It has been committed ([Here](https://github.com/l2dit/NotesRUs/commit/13cd3977c9d23848d1671896f7f620da0387b262)) I have written some demo code. The entity gives a simple way to interact with the data base in programmatic way not having to write database code. I have also cleaned out the main.rs file removing the command line code out into its own file. Along with this change and adding all the database code the project structure looks a lot different.I have now updated the kubernetes manifests removing Hanko and connecting directly to database with the app.
```rust title="DEMO Snippet"
// \\\\\\\\\\\DEMO-CODE\\\\\\\\\\
let user = users::ActiveModel {
	username: ActiveValue::set("notliam_99".into()),
	name: ActiveValue::set("Liam T".into()),
	most_recent_client: ActiveValue::not_set(),
	role: ActiveValue::not_set(),
	creation_time: ActiveValue::set(Local::now().into()),
	..Default::default()
};

let user = Users::insert(user).exec(&database).await;

println!("{user:?}");
// \\\\\\\\\\DEMO-CODE\\\\\\\\\
```

### 2024-08-18 Publish Crates
I have published the rust crates to [crates.io](https://crates.io/). Doing this also at the same time publishes the code to [docs.rs](https://docs.rs) making code documentation available to help people understand the inner working of the code.

| Crate Name            | Crates.io                                      | Docs.rs                                                             |
| --------------------- | ---------------------------------------------- | ------------------------------------------------------------------- |
| notes_r_us            | https://crates.io/crates/notes_r_us            | https://docs.rs/notes_r_us/latest/notes_r_us/                       |
| notes_r_us_migrations | https://crates.io/crates/notes_r_us_migrations | https://docs.rs/notes_r_us_migrations/latest/notes_r_us_migrations/ |
### 2024-08-26 Created New API Structure
Started work on creating the new API routes just defining paths and response/request body's. This work is not and will not be ready at this point we wont have enough time to ship a product this sprint. although this fact me and the rest of my group will keep pushing this project forward. This is very disappointing as we love the work we have done thus far.
# Testing Feedback
|   |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|
|Date|Session|Voter|What Do You Think Of The Current Name "Notes R Us": It Fits Our App|What Do You Think Of The Current Name "Notes R Us": Too Long|What Do You Think Of The Current Name "Notes R Us": Could Be Improved/Changed|What Would You Suggest As A Alternative Name? "Notes R Us": 1|What Would You Suggest As A Alternative Name? "Notes R Us": 2|What Do You Think Of Our New Logo, What Would You Like To See Different?:|
|2024-08-21|1|1|2|1|3|Niggers_aren't_us Cute_patootie_notes schoolschoolschool|||
|2024-08-21|2|2||||fuck nigga shit|||
|2024-08-21|3|3|2|3|5|Notes For You|Notes For You|Nothing|
|2024-08-21|3|4|5|1|2|||Looks like a tick|
|2024-08-21|3|5|5|3|1|Jsjsusk Hsoakaj Gsuaiaj|Jskajsj Sjsuisj Sjjsusi||
|2024-08-21|3|6|5|3|4|Skibidi_notes_r_us Crinkle Papyrus|Organised_Chaos Idea_freeflow|A bit bland of a color scheme. Don't really get what the leaf is meant to represent. Not really clear it's a notes app. But it's nice and clean and I like the simplistic aspect|
|2024-08-21|3|7|1|3|5|Papyrus palimpsest vellum||I like it, it’s pretty cool I disagree with Joel’s comment. However a solution to his concerns by adding the “vanes” of the feather.|
|2024-08-21|3|8|2|3|3|Nottie Share||I think that this logo is good|
|2024-08-21|3|9|5|1|3|Notes_for_you||Its good|
|2024-08-21|3|10|5|4|3|Noted|||
|2024-08-21|3|11|4|2|1|Notes_Are_Us||It is very clean and pretty cold. Much better than the old nonexistent logo.|
|2024-08-21|3|12|4|2|4|I Wouldnt Thecurrentnameisgood||Hard to tell what it is or what it's showing but it looks nice
# Sprint Review
> [!important]  
> Summarise key feedback from user testing, and what would become the focus for the next sprint  

This sprint was problematic in a lot of the same ways the last was. As a team we took on to much work for the amount of time we had free outside of other commitments. I found that sure I would have had enough time in a vacuum but I have too look out for my metal heath. unlike previous assessments they are short enough to go all out not this you become far more mentally fatigued from the push. This then becomes a feedback loop of recovering from the previous sprint then setting our goals as a team in a place we feel we can reach at the start of the sprint.
# Sprint Retrospective
> [!important]  
> Reflect on your progress throughout this sprint. Identify what went well, and what could be changed for the next sprint  

As mentioned above need to more carefully assess the amount of work your taking on for the sprint especially dealing with new technology.
### Links
- Link to release on Github: https://github.com/l2dit/NotesRUs/releases/tag/v0.3.0
- Project Board Screenshot (End of sprint): https://github.com/orgs/l2dit/projects/8
### Relevant Implications Discussion (IMPORTANT)
We addressed the relevant implications with the design of our database addressing privacy. We only collect minimal information as to not be intrusive to the user. only having columns in the table for the name of the user this is optional too so if a user wants to be anonymous they can.