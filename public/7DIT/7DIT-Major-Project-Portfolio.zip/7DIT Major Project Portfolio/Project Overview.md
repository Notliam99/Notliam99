---
tags:
  - 7dit
  - dit
publish: "true"
---
# Summary

- Each student (or small group) will select a unique project that results in a digital technologies outcome
- Every project must be approved by the teacher before starting. A formal project proposal document must be submitted
- The project will be assessed using [AS91897 - Use advanced processes to develop a digital technologies outcome](https://www.nzqa.govt.nz/nqfdocs/ncea-resource/achievements/2019/as91897.pdf)
- This project will be handed in at the end of Week 5, Term 3. The exact time and date will be communicated closer to the time, and is subject to change.

# Assessment Details

You will be assessed on

- how effectively you use **project management tools and techniques to plan and manage** the development of a digital outcome
- how effectively you **decompose the problem into smaller components**, and **test and refine** your digital outcome so that it is a high-quality project
- how well you have **addressed relevant implications**
- how well you **synthesise information from the planning, testing and trialling of components** to develop a high-quality outcome

# Project Selection

In consultation with your teacher, you will identify a suitable digital technologies project to work on. You have significant choice in what your project will be, and this is a deliberate decision to allow you to explore an area of interest. Throughout the project, you must make use of advanced processes as outlined in [AS91897 - Use advanced processes to develop a digital technologies outcome](https://www.nzqa.govt.nz/nqfdocs/ncea-resource/achievements/2019/as91897.pdf). This includes the use of project management tools and techniques which are outlined below.

# Project management tools and techniques

Examples include:

- saving backup copies with a logical file naming system
- using collaboration tools
- using simple version control software applications
- using tools or systems to plan tasks and milestones
- adjusting key actions and tasks where appropriate

A guide that outlines how to use Github to support this project is available here:

[[Github Guide]]

# Documenting Your Project

As you work through your project, it is important to document your progress. The examples below assume use of a project board implemented using Github and supported by your work in this Notion portfolio.

> [!important]  
> Note: If working as part of a small team, each person must develop their own documentation. This must clearly show the work that has been done by each team member, and how individuals have applied project management tools and techniques.  

### Notion Portfolio Documentation

Three separate Sprint pages have been created for you and linked from the portfolio dashboard. These pages contain a number of sections for you to fill in as you work. You are encouraged to modify these pages to suit your project if necessary.

- **Sprint Planning**: What you are aiming to achieve in the next sprint
- **Day to day development log**: Ongoing notes regarding project development, trialling and testing
- **Sprint Retrospective**: Share your latest release and gather feedback
- **Sprint Review**: Review your progress from the last sprint, and use this to inform planning for next sprint  
      
    

**Final release**

- A separate Notion page has been set up for your final release notes and documentation. This should include a discussion of how information gained from planning, testing and trialling project components has led to the development of a high quality digital technologies outcome.

### Github Repo / Project Documentation

- Your Github repository will contain your project files along with evidence of your ongoing code commits. Formal releases will be completed at the end of each sprint.
- Your Github project board will be used to plan and track each sprint. You should take screenshots of your project board at various stages throughout your project. This will help to demonstrate how you have implemented relevant project management techniques.

  

# Additional Assessment

Depending on the nature and content of your project, it may be possible to meet the requirements of additional Achievement Standards. Your focus should be on developing a really interesting and meaningful project. Additional assessments should be considered a bonus. Possible additional assessments include:

- [AS91892](https://www.nzqa.govt.nz/nqfdocs/ncea-resource/achievements/2019/as91892.pdf) - 2.3 Use advanced techniques to develop a database
- [AS91893](https://www.nzqa.govt.nz/nqfdocs/ncea-resource/achievements/2019/as91893.pdf) - 2.4 Use advanced techniques to develop a digital media outcome

  

> [!important]  
> For further information regarding how this project will be assessed, [[Assessment Information]]  
  
> [!important]  
> For instructions regarding how to submit your project, [[Handing in your project]]