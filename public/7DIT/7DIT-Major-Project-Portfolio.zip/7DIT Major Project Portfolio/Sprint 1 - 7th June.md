---
tags:
  - 7dit
  - dit
  - dit-28
  - dit-23
publish: "true"
---
# Sprint Planning
> [!important]  
> At the start of each sprint, look through your backlog and decide which tasks you will aim to complete during this sprint. Add these tasks to the relevant sprint, and add labels indicating which relevant implications each task addresses  

### Project Board Screenshot (Start of sprint)
20/4/2024
![[Pasted image 20240520195725.png]]

### Commentary (including brief outline of how relevant implications will be addressed)

  

  

# Development Log
> [!important]  
> As you work on your project, take note of key trialling and testing in this section  
##  2024-05-20 Infrastructure layout of the database and app
I have decided on a database for the application. I have decided against the use of sled sue to the complexity involved in creating a high availability deployment of it. this is due to inherit flaws of file systems; you would have overwrites and file conflicts if you had a high flow of traffic asynchronously writing to the same file system.

**What Is The Savor**
[Cloud Native PG](https://cloudnative-pg.io) a cloud native PostgreSQL database. It Drastically simplify the deployment of PostgreSQL on [[kubernetes]] it also implements many standards found in normal PostgreSQL clusters. I does this by being a [custom kubernetes controller](https://github.com/cloudnative-pg/cloudnative-pg) written in my teachers current favorite language Go-lang. It allows easy dashboard logging using Prometheus and [grafana](https://cloudnative-pg.io/documentation/1.23/quickstart/#grafana-dashboard).

### [Application Layout](https://cloudnative-pg.io/documentation/1.23/use_cases/)
![[Pasted image 20240520192950.png]]
### [Database Monitoring](https://cloudnative-pg.io/documentation/1.23/quickstart/#grafana-dashboard) `potentialy latter sprint...`
![[Pasted image 20240520195350.png]]
## 2024-05-21  Docker Builds Git Hub Actions
https://github.com/l2dit/NotesRUs/issues/15
i keept braking curently theres a fix waiting to be pushed into master

## 2024-05-23 PostgreSQL works !!!
I had to install a nfs provisioner it creates sub-directory's for volumes to be stored in on my nfs server dynamically. ![[Pasted image 20240523202329.png]] This means i don't have to manually create volumes for each Pod/Container by hand. I used this [GUIDE/PLUGIN](https://github.com/kubernetes-sigs/nfs-subdir-external-provisioner) this also means that i can setup dynamic ramp up and ramp down too.
```yaml title="kubernetes/1-cnpg.yaml"
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgresql-pvc-template
spec:
  instances: 3

  storage:
    storageClass: nfs-client
    size: 1Gi
```
It makes the database just a single file simplification at least for this app not the extra dependency.
## 2024-05-25 Small CI update 
made so it builds for multiple architectures.
```yaml title="push_master.yaml"
name: On Push To Master

# ... Actual changes not hole file
  - name: Setup QEMU
	uses: docker/setup-qemu-action@v3
	
  - name: Docker Build & Push
	uses: docker/build-push-action@v5
	with:
	  context: .
	  platforms: linux/386,linux/amd64,linux/arm/v7,linux/arm64,linux/ppc64le,linux/s390x
	  push: true
	  tags: |
		asskit/notesrus:${{ github.sha }}
		asskit/notesrus:latest
		ghcr.io/${{ env.REPO }}:${{ github.sha }}
		ghcr.io/${{ env.REPO }}:latest
	  file: ./Dockerfile 
```
## 2024-05-25 Kubernetes Is Done
### Architecture change...
![[Pasted image 20240525201523.png]]
I have added Pg Bouncer this is responsible for rate limiting and other security features.
### Manifests
Manifests are complete if you want a high level of whats happening look [HERE](https://argocd.nzdev.org/applications/argocd/notes-r-us). I have exposed the necessary environment variables to the container for a data base connection.
```bash title="Enviroment Vars"
# Application Enviroment Vars
PORT="3000"
ORIGNS="0.0.0.0"
KUBERNETES="true"

# PostgreSQL Enviroment Vars
POSTGRESQL_USERNAME=<username_secret>
POSTGRESQL_PASSWORD=<password_secret>
POSGRESQL_IP=<postgresql_ip_address>
POSGRESQL_IP=<posgresql_port>
```
## 28/5/24 Update Enviroment Vars And Implement 
changed the env vars all done in the kubernetes branch
## 29/5/24 docker Builds
Working on simplifying the docker builds as its taking too much action time.
## 30/5/24 Docker Builds
Have changed the compile of each step to be done on bare metal this time should improve performance quite a lot.

## 3/6/24 CI Head aches
The Last Couple days of delve time have been spent on fix and patching continuous integration. as were coming up to MVP they call it ingratiation nightmare. but i have done it also integrating branches of code together. its now deployed to https://notesrus.nzdev.org/ using memory as storage. This is because there was not enough time to get to the integration of the PostgreSQL data base. Adding the database is at the top of my list for the next sprint.
# Testing Feedback
> [!info] 4/6/24 
> ##  Early Test Feedback 
>  We have given some people the domain it does work but it has been described a clunky. We do not have a editor so it takes either a third party editor or previous knowledge of the markdown standard. This a feature we hope to work on during the next sprint. 
> ### Demographic
> The demographic were mostly people well versed in using a computer as they were students, but had no experience with the markdown standard.

> [!info] 5/6/24 
> ## Testing Day
> We had our testing day. Where we showcased our product to the rest of the class. 
> ### User Demographic
> The demographic were mostly people well versed in using a computer as they were students, but had no experience with the markdown standard.
> ### Feedback and Quotes
> That The system is not outlined enough to make it easier to use.
# Sprint Review
> [!important]  
> Summarise key feedback from user testing, and highlight areas of focus for next sprint  

For next sprint we have already discussed ideas of what we want to include in this next push. There is almost too much stuff. Number one for me at least is implementing PostgreSQL into the API. Lot of time i'll have to set aside to schema design. I'll also need to setup basic authentication and profanity detection.
# Sprint Retrospective
> [!important]  
> Reflect on your progress throughout this sprint. Identify what went well, and what could be changed for the next sprint  

In thinking back on the last 4 weeks of work our team organisation could have been a bit better. especial when it comes to communicating when developer work is being done. Going forward were probably going to have to do a stand up meeting at least once a week. To catch up on current progress and priority's and sort our developer load. 
### Relevant Implications Discussion (IMPORTANT)
 I only touched on the functionality side of recent implications. I only had chance to work on the deployment of the application. I focused on the docker action, docker file and learning/creating the kubernetes manifests.
### Commentary

### Info
- **Link to release on Git Hub:** https://github.com/l2dit/NotesRUs/releases/tag/v0.1.0
- **Project Board (End of sprint):** https://github.com/orgs/l2dit/projects/4