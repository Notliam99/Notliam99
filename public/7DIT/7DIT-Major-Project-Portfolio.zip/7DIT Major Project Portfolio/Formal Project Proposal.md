---
tags:
  - 7dit
  - dit
publish: "true"
---
> [!important]  
> Student / Group Name:  [L2Dit](https://github.com/L2Dit)
  
> [!important]  
> Project Title:  Notes R us

## Nominated Assessments (remove two)
- 2.8 - Processes (6 credits)
- 2.3 - Databases (4 credits)
  
### Project Description & Purpose
Online Blogging platform first goal of holding blog/note information in a database accessible through a API. To enable the sharing of these through share links. A final goal of a full Stack app more than just a API having a fleshed out user experience/user interface.

### Problem, issue, interest or opportunity that is being addressed
The Current way of sharing notes in school especially in science classes. where google sites are widely used in the department for note taking and sharing. Google sites has a old user interface using a proprietary standards standards. With our application well use open standards like markdown that can be edited by a large array of applications.

### End Users
An example end user would be a student. A student could make a Homework document then upload it and get it check by a teacher. I use a similar service Quartz a static site generator for markdown notes. That i use for school like one of our targret end user would use it as.

### Key Resources
Server resources for hosting the API application. That facilitates the Upload and the management of these documents e.g. the viewing, archiving or deleting of notes. A front end client that interfaces with the documents through the API to preform actions mentioned above. 

### Key Project Components
API server using [poem](https://docs.rs/crate/poem/latest) and [poem-openapi](https://docs.rs/crate/poem-openapi/latest) less established but stable with auto API documentation using the [OpenApi standard](https://swagger.io/specification/) . API client using either [leptos](https://docs.rs/crate/leptos/latest) a rust front end framework with a well establish surrounding ecosystem. Plus using [tailwind](https://tailwindui.com) for styling for components. For a data base well run [Postgres](https://www.postgresql.org/) database a well established database in the industry.

### My Responsibilities
Manage the Git Repository checking best practices along with the rest of the team. Data base development and infrastructure. Primary infrastructure/DevOps engineer. Plus integration into the API.

### Minimum Viable Product (MVP) Specs
A asynchronous API built in rust to Upload, delete and request the documents stored in a database. On top of this well build a simple user interface to facilitate these actions. 
  

- [x] Teacher has checked and approved this project proposal

Date: 15/5/24