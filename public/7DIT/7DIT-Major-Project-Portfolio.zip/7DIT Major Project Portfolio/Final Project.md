---
tags:
  - 7dit
  - dit
publish: "true"
---
> [!important]  
> Authenticity DeclarationI confirm that, for this project: All of the work submitted is my own, with the possible exception of publicly available code snippets which have been appropriately referenced I understand that I may be asked to explain aspects of my project, and a reasonable level of understanding must be evident to meet the requirements of the Achievement Standard  

# Final release on Github
https://github.com/l2dit/NotesRUs/releases/tag/v0.3.0
# Final Commentary

> [!important]  
> Write a summary of your project overall. For Excellence, this must include an extensive discussion about how the information from planning, testing and trialling of components assisted in the development of a high-quality outcome

> [!important]
>  ℹ️ Write a summary of your project overall. For Excellence in AS 91897, this must include an extensive discussion about how the information from planning, testing and trialling of components assisted in the development of a high-quality outcome 
>  
>  Many decisions I made during my development assisted me in making a high-quality outcome.

### Planning
As a whole planing was a massive focus for us as a team from picking frameworks and our tech stacks were crucial to our project. sadly planing does take valuable developing time you will see this as a trend 12 weeks quickly went by for our team. Saying this we spent almost all of sprint 2 on experimenting with new ideas for our apps infrastructure. At first we looked into hosting a opensource micro service for managing all our authentication but in the end we have come up with our own bespoke solution. involving a client token driven system with logins be driven by other authenticated clients or recovery codes. making the app far simpler to use and integrate into other apps like if you had wanted to develop a custom client for the API. Another major decision we made was on the data base we were going to employ. We had a couple requirements for our database It needed to be based off or a reliable industry standard and easily deployed with kubernetes. Kubernetes was a big consideration for our app as this would make it easy to adapt to almost any cloud provider. We end up with a variant of PostgreSQL we haven't had time to implement the database sadly but have created the schema.
### Development process
The development processes was quite an adjustment to how I worked. It was a big change due to our team using best practices using GitHub by utilizing pull request and GitHub issues. This added a lot of resistance to the development flow with having to use these effectively. We managed to rapidly develop a demo in our first sprint. After this first sprint we took time to plan our tech stack this took a significant amount of time. Due to this we were not able to fully develop an database integrated app in time for the end of sprint 2.
### Trialing of multiple components
We trialed our app but haven't had the required time to get adquite re-prototyping to feedback. we got lots of feedback on our features like like our name and logo and getting feedback on these to improve in future iterations.